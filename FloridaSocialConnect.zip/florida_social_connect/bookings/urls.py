from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("booking-received/", views.booking_success, name="booking_success"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("dashboard/export/", views.export_bookings, name="export_bookings"),
    path("dashboard/booking/<int:pk>/", views.booking_detail, name="booking_detail"),
    path("dashboard/booking/<int:pk>/status/", views.update_status, name="update_status"),
    path("dashboard/booking/<int:pk>/email/", views.send_customer_email, name="send_customer_email"),
]

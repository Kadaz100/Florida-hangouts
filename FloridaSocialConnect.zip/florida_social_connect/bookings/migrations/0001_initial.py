from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(
            name="Booking",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("city", models.CharField(max_length=80)),
                ("activity", models.CharField(choices=[("meet_greet", "Meet & Greets"), ("coffee", "Coffee & Conversation"), ("dinner", "Dinner Experiences"), ("city_tour", "City Exploration"), ("events", "Parties & Events"), ("special", "Special Social Experiences")], max_length=30)),
                ("duration", models.CharField(max_length=20)),
                ("booking_date", models.DateField()),
                ("email", models.EmailField(max_length=254)),
                ("notes", models.CharField(blank=True, max_length=500)),
                ("age_confirmed", models.BooleanField(default=False)),
                ("terms_accepted", models.BooleanField(default=False)),
                ("status", models.CharField(choices=[("pending", "Pending"), ("approved", "Approved"), ("completed", "Completed"), ("cancelled", "Cancelled")], default="pending", max_length=20)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"ordering": ["-created_at"]},
        ),
        migrations.CreateModel(
            name="EmailLog",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("recipient", models.EmailField(max_length=254)),
                ("subject", models.CharField(max_length=180)),
                ("body", models.TextField()),
                ("sent_by", models.CharField(blank=True, max_length=150)),
                ("sent_at", models.DateTimeField(auto_now_add=True)),
                ("successful", models.BooleanField(default=False)),
                ("error_message", models.CharField(blank=True, max_length=500)),
                ("booking", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="email_logs", to="bookings.booking")),
            ],
            options={"ordering": ["-sent_at"]},
        ),
    ]

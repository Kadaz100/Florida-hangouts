import csv
from datetime import date
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.core.mail import send_mail
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.views.decorators.http import require_POST
from .forms import BookingForm
from .models import Booking, EmailLog

def home(request):
    if request.method == "POST":
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save()
            subject = "We received your booking request"
            body = (
                f"Thank you. Your request for {booking.get_activity_display()} "
                f"in {booking.city} on {booking.booking_date} has been received. "
                "It is pending review. This is an acknowledgement, not a confirmed booking."
            )
            log = EmailLog.objects.create(
                booking=booking, recipient=booking.email, subject=subject,
                body=body, sent_by="Automatic booking acknowledgement"
            )
            try:
                send_mail(subject, body, None, [booking.email], fail_silently=False)
                log.successful = True
                log.save(update_fields=["successful"])
            except Exception as exc:
                log.error_message = str(exc)[:500]
                log.save(update_fields=["error_message"])
            return redirect("booking_success")
    else:
        form = BookingForm()
    return render(request, "bookings/home.html", {"form": form})

def booking_success(request):
    return render(request, "bookings/success.html")

@staff_member_required
def dashboard(request):
    qs = Booking.objects.all()
    search = request.GET.get("q", "").strip()
    status = request.GET.get("status", "").strip()
    city = request.GET.get("city", "").strip()
    date_from = request.GET.get("from", "").strip()
    date_to = request.GET.get("to", "").strip()

    if search:
        qs = qs.filter(Q(email__icontains=search) | Q(city__icontains=search) | Q(notes__icontains=search))
    if status in dict(Booking.STATUS_CHOICES):
        qs = qs.filter(status=status)
    if city:
        qs = qs.filter(city=city)
    if date_from:
        try:
            qs = qs.filter(booking_date__gte=date.fromisoformat(date_from))
        except ValueError:
            messages.warning(request, "Invalid start date filter.")
    if date_to:
        try:
            qs = qs.filter(booking_date__lte=date.fromisoformat(date_to))
        except ValueError:
            messages.warning(request, "Invalid end date filter.")

    stats_qs = Booking.objects.all()
    stats = {
        "total": stats_qs.count(),
        "pending": stats_qs.filter(status="pending").count(),
        "approved": stats_qs.filter(status="approved").count(),
        "completed": stats_qs.filter(status="completed").count(),
    }
    cities = Booking.objects.order_by("city").values_list("city", flat=True).distinct()
    return render(request, "bookings/dashboard.html", {
        "bookings": qs[:200], "stats": stats, "cities": cities,
        "filters": {"q": search, "status": status, "city": city,
                    "from": date_from, "to": date_to},
        "result_count": qs.count(),
    })

@staff_member_required
def export_bookings(request):
    qs = Booking.objects.all()
    status = request.GET.get("status", "").strip()
    city = request.GET.get("city", "").strip()
    search = request.GET.get("q", "").strip()
    if status in dict(Booking.STATUS_CHOICES):
        qs = qs.filter(status=status)
    if city:
        qs = qs.filter(city=city)
    if search:
        qs = qs.filter(Q(email__icontains=search) | Q(city__icontains=search) | Q(notes__icontains=search))

    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="florida-social-bookings.csv"'
    writer = csv.writer(response)
    writer.writerow(["ID", "Email", "City", "Activity", "Duration", "Booking date",
                     "Status", "Notes", "Submitted at"])
    for item in qs:
        writer.writerow([item.pk, item.email, item.city, item.get_activity_display(),
                         item.duration, item.booking_date, item.get_status_display(),
                         item.notes, item.created_at])
    return response

@staff_member_required
def booking_detail(request, pk):
    booking = get_object_or_404(Booking, pk=pk)
    return render(request, "bookings/booking_detail.html", {
        "booking": booking, "email_logs": booking.email_logs.all()
    })

@staff_member_required
@require_POST
def update_status(request, pk):
    booking = get_object_or_404(Booking, pk=pk)
    new_status = request.POST.get("status")
    if new_status in dict(Booking.STATUS_CHOICES):
        booking.status = new_status
        booking.save(update_fields=["status", "updated_at"])
        messages.success(request, "Booking status updated.")
    else:
        messages.error(request, "Invalid status.")
    return redirect("booking_detail", pk=pk)

@staff_member_required
@require_POST
def send_customer_email(request, pk):
    booking = get_object_or_404(Booking, pk=pk)
    subject = request.POST.get("subject", "").strip()[:180]
    body = request.POST.get("body", "").strip()[:10000]
    if not subject or not body:
        messages.error(request, "Enter both an email subject and message.")
        return redirect("booking_detail", pk=pk)

    log = EmailLog.objects.create(
        booking=booking, recipient=booking.email, subject=subject,
        body=body, sent_by=request.user.get_username()
    )
    try:
        send_mail(subject, body, None, [booking.email], fail_silently=False)
        log.successful = True
        log.save(update_fields=["successful"])
        messages.success(request, f"Email sent to {booking.email}.")
    except Exception as exc:
        log.error_message = str(exc)[:500]
        log.save(update_fields=["error_message"])
        messages.error(request, "Email could not be sent. Check SMTP settings in .env.")
    return redirect("booking_detail", pk=pk)

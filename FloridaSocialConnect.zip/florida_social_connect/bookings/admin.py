from django.contrib import admin
from .models import Booking, EmailLog

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ("email", "city", "activity", "booking_date", "duration", "status", "created_at")
    list_filter = ("status", "city", "activity", "booking_date")
    search_fields = ("email", "city", "notes")
    list_editable = ("status",)
    readonly_fields = ("created_at", "updated_at")
    ordering = ("-created_at",)
    def has_delete_permission(self, request, obj=None):
        return request.user.is_superuser

@admin.register(EmailLog)
class EmailLogAdmin(admin.ModelAdmin):
    list_display = ("recipient", "subject", "booking", "successful", "sent_by", "sent_at")
    list_filter = ("successful", "sent_at")
    search_fields = ("recipient", "subject", "body")
    readonly_fields = ("booking", "recipient", "subject", "body", "sent_by",
                       "sent_at", "successful", "error_message")
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def has_delete_permission(self, request, obj=None):
        return request.user.is_superuser

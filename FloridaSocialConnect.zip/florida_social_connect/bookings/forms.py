from django import forms
from django.utils import timezone
from .models import Booking

class BookingForm(forms.ModelForm):
    age_confirmed = forms.BooleanField(
        required=True, label="I confirm I am 18 or older."
    )
    terms_accepted = forms.BooleanField(
        required=True, label="I agree to the booking guidelines and privacy notice."
    )

    class Meta:
        model = Booking
        fields = [
            "city", "activity", "duration", "booking_date", "email",
            "notes", "age_confirmed", "terms_accepted",
        ]
        widgets = {
            "city": forms.Select(choices=[
                ("Miami", "Miami"), ("Orlando", "Orlando"), ("Tampa", "Tampa"),
                ("Jacksonville", "Jacksonville"), ("Fort Lauderdale", "Fort Lauderdale"),
                ("Tallahassee", "Tallahassee"), ("Naples", "Naples"),
                ("West Palm Beach", "West Palm Beach"), ("Sarasota", "Sarasota"),
                ("St. Petersburg", "St. Petersburg"), ("Clearwater", "Clearwater"),
                ("Gainesville", "Gainesville"), ("Daytona Beach", "Daytona Beach"),
            ]),
            "activity": forms.Select(),
            "duration": forms.Select(choices=[
                ("1 day", "1 day"), ("2 days", "2 days"), ("3 days", "3 days"),
                ("5 days", "5 days"), ("7 days", "7 days"),
            ]),
            "booking_date": forms.DateInput(attrs={"type": "date"}),
            "email": forms.EmailInput(attrs={"placeholder": "you@example.com"}),
            "notes": forms.TextInput(attrs={"placeholder": "Optional details", "maxlength": "500"}),
        }

    def clean_booking_date(self):
        value = self.cleaned_data["booking_date"]
        if value < timezone.localdate():
            raise forms.ValidationError("Choose today or a future date.")
        return value

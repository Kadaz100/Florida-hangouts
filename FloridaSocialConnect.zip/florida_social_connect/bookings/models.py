from django.db import models

class Booking(models.Model):
    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("approved", "Approved"),
        ("completed", "Completed"),
        ("cancelled", "Cancelled"),
    ]
    ACTIVITY_CHOICES = [
        ("meet_greet", "Meet & Greets"),
        ("coffee", "Coffee & Conversation"),
        ("dinner", "Dinner Experiences"),
        ("city_tour", "City Exploration"),
        ("events", "Parties & Events"),
        ("special", "Special Social Experiences"),
    ]
    city = models.CharField(max_length=80)
    activity = models.CharField(max_length=30, choices=ACTIVITY_CHOICES)
    duration = models.CharField(max_length=20)
    booking_date = models.DateField()
    email = models.EmailField()
    notes = models.CharField(max_length=500, blank=True)
    age_confirmed = models.BooleanField(default=False)
    terms_accepted = models.BooleanField(default=False)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.email} — {self.city} — {self.booking_date}"


class EmailLog(models.Model):
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name="email_logs")
    recipient = models.EmailField()
    subject = models.CharField(max_length=180)
    body = models.TextField()
    sent_by = models.CharField(max_length=150, blank=True)
    sent_at = models.DateTimeField(auto_now_add=True)
    successful = models.BooleanField(default=False)
    error_message = models.CharField(max_length=500, blank=True)

    class Meta:
        ordering = ["-sent_at"]

    def __str__(self):
        return f"{self.recipient} — {self.subject}"

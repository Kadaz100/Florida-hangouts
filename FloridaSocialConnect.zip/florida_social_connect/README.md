# Florida Social Connect

Django starter for a platonic social-experience booking service: meet & greets, coffee, dinners, sightseeing and events. It is not for arranging sexual services.

## Run locally
1. Install Python 3.11+.
2. Create/activate a virtual environment.
3. `pip install -r requirements.txt`
4. Copy `.env.example` to `.env`; replace `SECRET_KEY` with a long random value.
5. Run `python manage.py makemigrations bookings`
6. Run `python manage.py migrate`
7. Run `python manage.py createsuperuser`
8. Run `python manage.py runserver`
9. Website: `http://127.0.0.1:8000/`
10. Staff dashboard: `http://127.0.0.1:8000/dashboard/`
11. Django admin: `http://127.0.0.1:8000/admin/`

## Dashboard additions
- Search bookings by email, city and notes.
- Filter by status, city and requested date range.
- Export all matching bookings to CSV.
- Review email attempts and delivery outcomes.
- Send a direct email to the address on an individual booking.
- Automatic booking acknowledgement attempt after submission.

## Email setup
Set SMTP values in `.env`. Gmail requires an App Password (with 2-step verification); do not use your normal password. Until credentials are configured, Django uses the console email backend and writes messages to the terminal. Email logs show whether Django handed the message to the configured mail backend; they do not guarantee inbox delivery.

## Important before public launch
- SQLite is for development. Use PostgreSQL in production.
- Set `DEBUG=False`, a strong secret, HTTPS, secure cookies, correct `ALLOWED_HOSTS`, and trusted CSRF origins.
- Add rate limiting, spam protection, backup and retention policies.
- The age checkbox is a declaration, not age verification.
- Profile photos/listings require explicit consent and moderation.
- Do not publish real customer data in screenshots or demos.
